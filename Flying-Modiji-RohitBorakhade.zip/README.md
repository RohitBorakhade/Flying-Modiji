# Flying-Modiji — Rohit B (Personalized ZIP)

This ZIP was prepared for **RohitBorakhade** to quickly upload a forked copy of the *Flying-Modiji* game to GitHub Pages.

**What this archive contains**
- `index.html` — page title and footer credit changed to **"Flying Modiji by Rohit B"** and GitHub link to https://github.com/RohitBorakhade
- `style.css` — minimal styling and references `background.webp`
- `script.js` — placeholder JS so the page loads. **It is NOT the original game logic.**
- placeholder assets: `background.webp`, `bird.png`, `gameover.mp3`, `thaka.mp3`

**Important — to get the full working game**
1. Go to the original repository: https://github.com/divyansh1502/Flying-Modiji
2. Download the original files (or fork the original and copy the actual `script.js` and other assets).
3. Replace the placeholder `script.js`, `bird.png`, `background.webp`, and sound files in this archive with the originals from the repository.
4. Commit and push the files to your GitHub repo `RohitBorakhade/Flying-Modiji`.
5. Publish GitHub Pages: Settings → Pages → Branch **main / (root)** → Save.
6. Your site should be available at: `https://rohitborakhade.github.io/Flying-Modiji/`
