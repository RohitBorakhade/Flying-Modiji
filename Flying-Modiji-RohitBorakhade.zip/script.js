// Placeholder script for Flying Modiji by Rohit B
const canvas = document.getElementById('canvas');
const ctx = canvas.getContext('2d');
let score = 0;
document.getElementById('score').innerText = score;
document.getElementById('restart').addEventListener('click', ()=>{ score=0; document.getElementById('score').innerText = score; alert('Restart pressed — replace script.js with original to play full game.'); });
function draw(){
  ctx.clearRect(0,0,canvas.width,canvas.height);
  ctx.fillStyle = 'yellow';
  ctx.beginPath();
  ctx.arc(60,240,16,0,Math.PI*2);
  ctx.fill();
  requestAnimationFrame(draw);
}
draw();
